print ("sinh vien:Huynh Quoc Toan MSV:235752021610081")
ds = input('Nhap chuoi: ').split()
ds.remove('123')
for ch in ds:
    print(ch)
