print("Huynh Quoc Toan MSV:235752021610081")
with open('D:/a.txt', 'r', encoding='utf-8') as file:
    content = file.read()
print(content)
