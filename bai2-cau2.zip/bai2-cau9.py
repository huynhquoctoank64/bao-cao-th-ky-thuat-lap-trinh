print("sinh vien:Huynh Quoc Toan MSV:235752021610081")
str=input("Enter a String:")
dict = {}
for i in str:
    dict[i] = str.count(i)
print (dict)
