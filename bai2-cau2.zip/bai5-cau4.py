print("Huynh Quoc Toan MSV:235752021610081")
import numpy as np

# Tạo mảng với các giá trị từ 12 đến 38
array = np.arange(12, 39)

# Đảo ngược mảng
reversed_array = array[::-1]

print("Mảng ban đầu từ 12 đến 38:", array)
print("Mảng sau khi đảo ngược:", reversed_array)
