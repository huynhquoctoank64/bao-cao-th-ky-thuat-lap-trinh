print("sinh vien:Huynh Quoc Toan MSV:235752021610081")

n = int(input("Enter A Number--->"));
while n >= 0:
    print (n);
    n = n - 1;

