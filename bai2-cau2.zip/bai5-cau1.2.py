print("Huynh Quoc Toan MSV:235752021610081")
# Sử dụng module mymath với tên rút gọn là mt
import mymath as mt
# Gọi các hàm trong mymath thông qua tên mới là mt
print(mt.square(2))  # In ra bình phương của 2
print(mt.square(3))  # In ra bình phương của 3
