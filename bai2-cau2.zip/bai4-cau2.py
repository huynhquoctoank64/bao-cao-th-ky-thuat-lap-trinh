print ("sinh vien:Huynh Quoc Toan MSV:235752021610081")
S = input('Nhap chuoi:')
for ch in S:
    if ch not in [' ','\t']:
        print(ch)
