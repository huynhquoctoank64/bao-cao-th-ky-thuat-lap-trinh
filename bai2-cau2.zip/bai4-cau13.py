print ("sinh vien:Huynh Quoc Toan MSV:235752021610081")
ds = input('Nhap chuoi: ').split()
print("vị trí của chuỗi abc là", ds.index('abc'))
