print("Huynh Quoc Toan MSV:235752021610081")
import numpy as np
x = np.arange(12, 38)
print(x)
