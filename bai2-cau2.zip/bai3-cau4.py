print ("Sinh vien:Huynh Quoc Toan MSV:23575202161010081")
# Biến toàn cục
a = "Hello MAi!"
def say(a):
    # Biến cục bộ trong hàm say
    a = "Vinh University"
    print(a)
# Gọi hàm say với biến toàn cục a
say(a)
# In biến toàn cục a sau khi gọi hàm
print(a)

