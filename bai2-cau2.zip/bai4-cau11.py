print ("sinh vien:Huynh Quoc Toan MSV:235752021610081")
ds = input("Nhập chuỗi: ").split()
ds.append('abc')
for ch in ds:
    print(ch)
