print ("sinh vien:Huynh Quoc Toan MSV:235752021610081")
ds = input('Nhap chuoi: ').split()
x = ds[1:-1]
for c in x:
    print(c)
