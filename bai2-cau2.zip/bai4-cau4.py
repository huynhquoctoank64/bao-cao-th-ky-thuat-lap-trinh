print ("sinh vien:Huynh Quoc Toan MSV:235752021610081")
ds = input('Danh sách: ').split()
#in cả dãy vừa nhập
print(ds)
#in dãy vừa nhập, mỗi phần tử trên một dòng
for so in ds:
    print(so)
