print ("sinh vien:Huynh Quoc Toan MSV:235752021610081")
Tên_người = input("Nhập tên người (gồm họ và tên riêng): ")
Họ_tên = Tên_người.split()
ho = Họ_tên[0]  
ten_rieng = Họ_tên[-1]  
print("Họ:", ho)
print("Tên riêng:", ten_rieng)
