print("sinh vien:Huynh Quoc Toan MSV:235752021610081")
a="hi i am NguyenVanTung"
b=a.split()
print (b)
c=" ".join(b)
print(c)
