print("sinh vien:Huynh Quoc Toan MSV:235752021610081")

i=1;
for j in range(2,10):
    print("i:",i,"j:",j)
    print(i,"/",j)
    print (i/j);
