print("Huynh Quoc Toan  MSV:235752021610081")
k=open('D:/a.txt','r')
char,wc,lc=0,0,0
for line in k:
    for k in range(0,len(line)):
        char +=1
        if(line[k]==' '):
            wc+1
        if(line[k]=='\n'):
            wc,lc=wc+1,lc+1
print("The no.of chars is %d\n The no.of words is %d\n The no.of lines is %d"%(char,wc,lc))
