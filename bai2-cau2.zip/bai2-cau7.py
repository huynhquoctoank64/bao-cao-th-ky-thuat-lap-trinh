print("sinh vien:Huynh Quoc Toan MSV:235752021610081")

n=int(input("Nhập vào một số: "))
d=dict()
for i in range(1,n+1) :
    d[i]=i*i

print (d)
            
