print("sinh vien:Huynh Quoc Toan MSV:235752021610081")

n=int(input("Enter a number---->"))
if n % 2 == 0:
    print ("EVEN Number");
else:
    print ("ODD Number");
