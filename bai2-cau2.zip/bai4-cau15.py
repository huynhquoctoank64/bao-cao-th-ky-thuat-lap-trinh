print ("sinh vien:Huynh Quoc Toan MSV:235752021610081")
words = input("Nhập các từ tiếng Anh: ").split()
words.sort()
print("Các từ theo thứ tự từ điển:")
for word in words:
    print(word)
