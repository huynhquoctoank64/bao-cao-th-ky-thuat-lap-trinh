print ("Sinh vien:Huynh Quoc Toan MSV:235752021610081")
a = "Hello"
def say_hello():
    print(a) 
print(a) 
