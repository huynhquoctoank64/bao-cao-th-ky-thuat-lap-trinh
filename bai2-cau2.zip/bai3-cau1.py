print ("Sinh vien:Huynh Quoc Toan MSV:235752021610081")
def sum(a, b):
    print("sum="+str(a+b))
#tinh tong 2 so 4,5
sum(4, 5)
#tinh tong 2 so 3,7
sum(3, 7)
