print("sinh vien:Huynh Quoc Toan MSV:235752021610081")

l=["HuynhQuocToan"]
k=[19]
m=[]
m.append(l);
m.append(k);
print (m)
d={"hoten":l,"tuoi":k,'combine_list':m}
print (d)
