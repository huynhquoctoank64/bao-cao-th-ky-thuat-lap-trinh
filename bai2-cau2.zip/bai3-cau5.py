print ("Sinh vien:Huynh Quoc Toan MSV:235752021610081")
a = "Hello Guy!" 
def say():
    global a
    a = " Vinh University "
    print(a) 
say() 
print(a)
